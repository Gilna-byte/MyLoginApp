package com.example.myloginapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.view.View;

public class MyDbclass extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "ContactsDB";
    private static final String DATABASE_VERSION = "1";
    private static final String TABLE_CONTACT = "contacts";
    private static final String KEY_ID ="id";
    private static final String KEY_PHONE_NO = "phone_no";


    public MyDbclass(View.OnClickListener context) {
        super((Context) context, DATABASE_NAME, null, Integer.parseInt(DATABASE_VERSION));
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_CONTACT +
                "("  + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"

                + KEY_PHONE_NO + " INT(10)"
                + ")");
        SQLiteDatabase database= this.getWritableDatabase();
        database.close();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CONTACT);
        onCreate(db);

    }
    public boolean addContact(String id, String phone_no){
        SQLiteDatabase db= this.getWritableDatabase();

        ContentValues values= new ContentValues();
        values.put(KEY_ID,id);

        values.put(KEY_PHONE_NO,phone_no);

        long result= db.insert(TABLE_CONTACT,null,values);
        if(result==-1) return false;
        else
            return true;

    }
}
