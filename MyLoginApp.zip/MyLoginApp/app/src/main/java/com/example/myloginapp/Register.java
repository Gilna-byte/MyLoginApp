package com.example.myloginapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Register extends AppCompatActivity {
    private EditText phoneNumberEditText;
    private Button registerButton;
    private MyDbclass databaseHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        phoneNumberEditText = findViewById(R.id.PhoneNo);
        registerButton = findViewById(R.id.phnbutton);
        databaseHelper = new MyDbclass((View.OnClickListener) this);
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phoneNumber = phoneNumberEditText.getText().toString().trim();
                long userId = databaseHelper.addContact(phone_no);

                if (userId != -1) {
                    // Registration successful
                    Toast.makeText(Register.this, "Registration successful", Toast.LENGTH_SHORT).show();
                } else {
                    // Registration failed
                    Toast.makeText(Register.this, "Registration failed", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}


