package com.example.myloginapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btnRegister = findViewById(R.id.btnRegister);
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, Register.class);

                Toast.makeText(MainActivity.this,
                        "Please Register with your Phone Number",Toast.LENGTH_SHORT).show();

                startActivity(intent);

                MyDbclass dbclass=new MyDbclass(this);
                dbclass.addContact("1","9876543456");
                dbclass.addContact("1","9876543458");
                dbclass.addContact("1","9876547770");
                dbclass.addContact("1","9876543894");
                dbclass.addContact("1","9876543678");


            }
        });

    }
}